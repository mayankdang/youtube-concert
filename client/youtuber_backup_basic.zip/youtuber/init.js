chrome.runtime.sendMessage({method: "setIcon"}, function (response) {
});
